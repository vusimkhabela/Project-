// export const environment = {
//   production: true
// };

export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyDaFYfuvMexEmzVqf0F0PEY7m9gpvK1MDM',
    authDomain: 'photo-manager-73152.firebaseapp.com',
    databaseURL: 'https://photo-manager-73152.firebaseio.com',
    projectId: 'photo-manager-73152',
    storageBucket: 'photo-manager-73152.appspot.com',
    messagingSenderId: '909008209816'
  }
};
