﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = (string)Session["email_id"];
        SqlConnection con;
        Label1.Text = s;

        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        string query2 = "select image_path from reg where email_id='" + s + "'";
        SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1, "a");
        int k = ds1.Tables["a"].Rows.Count;
        if (k > 0)
        {
            Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label3.Text = TextBox1.Text;
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void LinkButton7_Click(object sender, EventArgs e)
    {

    }
    protected void ImageMap1_Click(object sender, ImageMapEventArgs e)
    {

    }
}
