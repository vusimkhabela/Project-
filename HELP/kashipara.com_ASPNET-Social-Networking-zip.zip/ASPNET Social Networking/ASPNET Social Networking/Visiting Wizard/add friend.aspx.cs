﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class add_friend : System.Web.UI.Page
{
    //string s;
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = (string)Session["email_id"];
        SqlConnection con;
        Label1.Text = s;

        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        string query2 = "select image_path from reg where email_id='" + s + "'";
        SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1, "a");
        int k = ds1.Tables["a"].Rows.Count;
        if (k > 0)
        {
            Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
                string s = (string)Session["email_id"];
        SqlConnection con =  new SqlConnection(ConfigurationManager.AppSettings["constring"].ToString());
        con.Open();
        string query1 = "select image_path from reg where email_id='" + TextBox1.Text + "'";
        SqlDataAdapter da = new SqlDataAdapter(query1, con);
        DataSet ds = new DataSet();
        da.Fill(ds, "t");
        int n = ds.Tables["t"].Rows.Count;
        string path=null;
        if (n > 0)
        {
            path = ds.Tables["t"].Rows[0][0].ToString();
        }
        string query = "insert into friend_table(email_id,f_id,f_image)values('" + s + "','" + TextBox1.Text + "','"+path+"')";
        SqlCommand com = new SqlCommand(query, con);
        com.ExecuteNonQuery();
    }
   
  }

