﻿
Partial Class friendz
    Inherits System.Web.UI.Page

End Class
