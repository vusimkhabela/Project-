﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class testimonial : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = (string)Session["email_id"];
        SqlConnection con;
        Label1.Text = s;

        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        string query2 = "select image_path from reg where email_id='" + s + "'";
        SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1, "a");
        int k = ds1.Tables["a"].Rows.Count;
        if (k > 0)
        {
            Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string s1 = (string)Session["email_id"];
        SqlConnection con;
        SqlDataAdapter ad;
        DataSet ds;
        SqlCommandBuilder cmd;
        string s = TextBox1.Text;
        con = new SqlConnection(ConfigurationManager.AppSettings["constring"].ToString());
       
        string strconnection = ConfigurationManager.AppSettings["constring"].ToString();
        con = new SqlConnection(strconnection);
        ad = new SqlDataAdapter("select * from testimonial", con);
        ds = new DataSet();
        cmd = new SqlCommandBuilder(ad);
        ad.Fill(ds, "dbo.testimonial");
        //ds.Tables[0].PrimaryKey = new DataColumn[] { ds.Tables[0].Columns[1] };
        //string name;
        DataRow dr;//dr1;
        //name = txt_d_name.Text;
        //dr1 = ds.Tables[0].Rows.Find(name);
        /*if (dr1 != null)
        {
            Label1.Visible = true;
        }
        else
        {*/
            dr = ds.Tables[0].NewRow();
            //dr[0]="recpient_id";
            dr[0] = s1;
            dr[2] = TextBox1.Text;
            dr[1] = TextBox2.Text;
            //dr[2] = txt_d_emailid.Text;
            //dr[3] = txt_d_pass.Text;
            //dr[4] = txt_d_address.Text;
            //dr[5] = txt_d_contactno.Text;
            ds.Tables[0].Rows.Add(dr);
            ad.Update(ds, "dbo.testimonial");
           // Response.Redirect("profile.aspx");
                     
       /* string query = "insert into scrapbook(recipent_id,scrap)values('" + TextBox1.Text + "','" + TextBox2.Text + "')where recipent_id=" + TextBox1.Text;
        ad = new SqlDataAdapter(query, con);
        ds = new DataSet();
        cmd = new SqlCommandBuilder(ad);
        ad.Fill(ds, "reg");*/
        Label4.Visible = true;
        Label4.Text = "Testimonial send successfully";
        TextBox1.Text = "";
    }
    }
