﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class friendprofile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string s1 = "";
        if (Request.QueryString["eid"] != null)
        {
            s1 = Request.QueryString["eid"].ToString();
        }
        string s = (string)Session["email_id"];
        SqlConnection con;
        Label1.Text = s1;
        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        string query2 = "select image_path from reg where email_id='" + s + "'";
        SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1, "a");
        int k = ds1.Tables["a"].Rows.Count;
        if (k > 0)
        {
            Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        }
        string query1 = "select * from reg where email_id='" + s1 + "'";
        SqlDataAdapter ad1 = new SqlDataAdapter(query1, con);
        DataSet ds2 = new DataSet();
        //   cmd = new SqlCommandBuilder(ad);
        ad1.Fill(ds2, "reg");
        int n1 = ds2.Tables["reg"].Rows.Count;
        if (n1 > 0)
        {
            Label25.Text = ds2.Tables["reg"].Rows[0][0].ToString();

            Label26.Text = ds2.Tables["reg"].Rows[0][1].ToString();
            Label27.Text = ds2.Tables["reg"].Rows[0][3].ToString();
            Label28.Text = ds2.Tables["reg"].Rows[0][4].ToString();
            Label29.Text = ds2.Tables["reg"].Rows[0][5].ToString();
            Label30.Text = ds2.Tables["reg"].Rows[0][6].ToString();
            Label31.Text = ds2.Tables["reg"].Rows[0][7].ToString();
            Label32.Text = ds2.Tables["reg"].Rows[0][8].ToString();
            Label33.Text = ds2.Tables["reg"].Rows[0][9].ToString();
        }
        string query3 = "select image_path from reg where email_id='" + s1 + "'";
        SqlDataAdapter da3 = new SqlDataAdapter(query3, con);
        DataSet ds3 = new DataSet();
        da3.Fill(ds3, "a");
        int k1 = ds3.Tables["a"].Rows.Count;
        if (k1 > 0)
        {
            Image1.ImageUrl = ds3.Tables["a"].Rows[0][0].ToString();
        }
    }

}
