﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class friendz : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = (string)Session["email_id"];
        SqlConnection con;
        Label1.Text = s;

        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        string query2 = "select image_path from reg where email_id='" + s + "'";
        SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1, "a");
        int k = ds1.Tables["a"].Rows.Count;
        if (k > 0)
        {
            Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        }
        string id = (string)Session["email_id"];
        con = new SqlConnection(ConfigurationManager.AppSettings["constring"].ToString());
        //SqlConnection con = new SqlConnection(str);
        con.Open();
        string qury = "select f_id,f_image from friend_table where email_id='"+id+"'";
        SqlCommand com = new SqlCommand(qury, con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "t");
        //Label3.Text = ds.Tables["t"].Rows.Count.ToString();
        ListView1.DataSource = ds.Tables["t"];
        ListView1.DataBind();
        ////if (!IsPostBack)
        ////{
        //ListView1.DataBind();
        ////}
    }
   // string str = "server=.;database=vw";
    protected void Button5_Click(object sender, EventArgs e)
    {

        //SqlConnection con = new SqlConnection(str);
        //con.Open();
        //FileUpload1.SaveAs(Server.MapPath("~/images/") + FileUpload1.FileName);
        //string s = "~/images/" + FileUpload1.FileName;

        //string query = "insert into friend values('" + TextBox1.Text + "','" + s + "')";
        //SqlCommand com = new SqlCommand(query, con);
        //com.ExecuteNonQuery();
        //Response.Write("ok");
        //con.Close();
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        //SqlConnection con = new SqlConnection(str);
        //con.Open();
        //string qury = "select path from friend where id='" + TextBox1.Text + "'";
        //SqlCommand com = new SqlCommand(qury, con);
        //SqlDataAdapter da = new SqlDataAdapter(com);
        //DataSet ds = new DataSet();
        //da.Fill(ds, "t");
        //string path = ds.Tables["t"].Rows[0][0].ToString();
        ////Image1.ImageUrl = "~/images/author.jpg";
        //Image1.ImageUrl = path;//@"file:///C:\Users\Gourav\Documents\Visual Studio 2008\WebSites\WebSite27\images\author.jpg.jpg";
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void ListView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
