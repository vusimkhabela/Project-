﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class editprofile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = (string)Session["email_id"];
        SqlConnection con;
        Label1.Text = s;
        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        string query2 = "select image_path from reg where email_id='" + s + "'";
        SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1, "a");
        int k = ds1.Tables["a"].Rows.Count;
        if (k > 0)
        {
            Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        }
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton1.Checked == true)
        {
            Label19.Visible = true;
            Label19.Text = "male";
        }
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
       if(RadioButton2.Checked==true)
        {
            Label19.Visible = true;
            Label19.Text = "female";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string s = (string)Session["email_id"];
      
        SqlConnection con;
       // SqlDataAdapter ad;
        DataSet ds;
        //SqlCommandBuilder cmd;
        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        con.Open();
      /*  string qury1 = "update reg set name='" + TextBox1.Text + "' where email_id= '" + s + "'";
        string q2 ="update reg set lastname='" + TextBox7.Text + "' where email_id= '" + s + "'";
        string q3 ="update reg set city='" + DropDownList5.Text + "' where email_id= '" + s + "'";
        string q4 = "update reg set dob='" + DropDownList2.Text + "'+'" + DropDownList3.Text + "''" + DropDownList4.Text + "' where email_id= '" + s + "'";
        string q5="update reg set age='" + TextBox3.Text + "' where email_id= '" + s + "'";
        string q6 ="update reg set gender='" + Label19.Text + "' where email_id= '" + s + "'";
        string q7="update reg set country='" + DropDownList6.Text + "' where email_id= '" + s + "'";
        string q8="update reg set contact_no='" + TextBox6 + "' where email_id= '" + s + "'";*/
        string q="update reg set name='" + TextBox1.Text + "' ,lastname='" + TextBox7.Text + "', city='" + DropDownList5.Text + "', dob='" + DropDownList2.Text+DropDownList3.Text+DropDownList4.Text + "' ,age=" + TextBox3.Text + ",gender='" + Label19.Text + "',country='" + DropDownList6.Text + "',contact_no=" + TextBox6.Text + " where email_id= '" + s + "'";
        SqlCommand com = new SqlCommand(q, con);
       /* com = new SqlCommand(qury1, con);
        com = new SqlCommand(q2, con);
        com = new SqlCommand(q3, con);
        com = new SqlCommand(q4, con);
        com = new SqlCommand(q5, con);
        com = new SqlCommand(q6, con);
        com = new SqlCommand(q7, con);
        com = new SqlCommand(q8, con);*/
//        SqlDataAdapter da = new SqlDataAdapter(com);
  //      ds = new DataSet();
      //  da.Fill(ds,"reg");
        /*string query = "insert into reg(name,lastname,city,dob,age,gender,country,contact_no)values('" + TextBox1.Text + "','" + TextBox7.Text + "','" + DropDownList5.Text + "','" + DropDownList2.Text + "','" + DropDownList3.Text + "','" + DropDownList4.Text + "','" + TextBox3.Text + "','" + Label19.Text + "','" + DropDownList6.Text + "','" + TextBox6.Text + "')";
        ad = new SqlDataAdapter(query, con);
        ds = new DataSet();
        cmd = new SqlCommandBuilder(ad);
        ad.Fill(ds, "reg");*/
        com.ExecuteNonQuery();
        com.Dispose();
        Response.Redirect("profile.aspx");
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
