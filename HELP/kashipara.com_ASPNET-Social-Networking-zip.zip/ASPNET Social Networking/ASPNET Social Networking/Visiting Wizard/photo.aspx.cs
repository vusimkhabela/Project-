﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class application : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = (string)Session["email_id"];
        SqlConnection con;
        Label1.Text = s;

        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        if (!IsPostBack)
        {
            bind();
           // con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
           
        }

        string query2 = "select image_path from reg where email_id='" + s + "'";
        SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        DataSet ds1 = new DataSet();
        da1.Fill(ds1, "a");
        int k = ds1.Tables["a"].Rows.Count;
        if (k > 0)
        {
            Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        }
    }
    public void bind()
    {
        string s = (string)Session["email_id"];
       SqlConnection con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
        string qury = "select email_id,image_path from photo where email_id='" + s + "'";
        SqlCommand com = new SqlCommand(qury, con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "t");
        //Label3.Text = ds.Tables["t"].Rows.Count.ToString();
        ListView1.DataSource = ds.Tables["t"];
        ListView1.DataBind();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        bind();
        string s = (string)Session["email_id"];
        SqlConnection con;

        con = new SqlConnection(@"server=.;initial catalog=vw;integrated security=true");
       // con.Open();
        FileUpload1.SaveAs(Server.MapPath("~/images/") + FileUpload1.FileName);
        string image_path1 = "~/images/" + FileUpload1.FileName;

        //string query = "insert into reg() values('" + "','" + image_path + "')";
        //SqlCommand com = new SqlCommand(query, con);
        //com.ExecuteNonQuery();
        //Response.Write("ok");        
        string qury1 = "insert into photo(email_id, image_path)values('"+s+"','" + image_path1 + "')"; 
            // where email_id='" + s + "'";"insert into reg( image_path)values('"+image_path1+"') where email_id='" + Label34.Text + "'";
        SqlCommand com = new SqlCommand(qury1, con);
        SqlDataAdapter da = new SqlDataAdapter(com);
        DataSet ds = new DataSet();
        da.Fill(ds, "photo");
      //  con.Close();
        // string path = ds.Tables["reg"].Rows[0][10].ToString();
        //string query2 = "select image_path from photo where email_id='" + s + "'";
        //SqlDataAdapter da1 = new SqlDataAdapter(query2, con);
        //DataSet ds1 = new DataSet();
        //da1.Fill(ds1, "a");
        //int k = ds1.Tables["a"].Rows.Count;
        //if (k > 0)
        //{
        //    Image1.ImageUrl = ds1.Tables["a"].Rows[0][0].ToString();
        //}
        //  Image1.ImageUrl = "~/images/" + FileUpload1.FileName; ;
        // Image1.ImageUrl = path;//@"D:\pravesh\WebSite11\App_Data\imagePicture 002.jpg";
        // con.Close();
        
     
    }
}
