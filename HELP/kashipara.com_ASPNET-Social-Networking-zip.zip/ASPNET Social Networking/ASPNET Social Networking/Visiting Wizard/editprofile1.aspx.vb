﻿
Partial Class editprofile1
    Inherits System.Web.UI.Page

End Class
