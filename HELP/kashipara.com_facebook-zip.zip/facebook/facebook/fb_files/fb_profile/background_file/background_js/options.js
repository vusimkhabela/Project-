	function open_option()
	{
		document.getElementById("option").style.display='block';
	}
	function close_option()
	{
		document.getElementById("option").style.display='none';
	}
	function head_timeline_over()
	{
		document.getElementById("head_timeline").style.textDecoration = "underline"
	}
	function head_timeline_out()
	{
		document.getElementById("head_timeline").style.textDecoration = "none"
	}
	function head_about_over()
	{
		document.getElementById("head_about").style.textDecoration = "underline"
	}
	function head_about_out()
	{
		document.getElementById("head_about").style.textDecoration = "none"
	}
	function head_photos_over()
	{
		document.getElementById("head_photos").style.textDecoration = "underline"
	}
	function head_photos_out()
	{
		document.getElementById("head_photos").style.textDecoration = "none"
	}
	function head_settings_over()
	{
		document.getElementById("head_settings").style.textDecoration = "underline"
	}
	function head_settings_out()
	{
		document.getElementById("head_settings").style.textDecoration = "none"
	}
	function head_logout_over()
	{
		document.getElementById("head_logout").style.textDecoration = "underline"
	}
	function head_logout_out()
	{
		document.getElementById("head_logout").style.textDecoration = "none"
	}
	function head_feedback_over()
	{
		document.getElementById("head_feedback").style.textDecoration = "underline"
	}
	function head_feedback_out()
	{
		document.getElementById("head_feedback").style.textDecoration = "none"
	}